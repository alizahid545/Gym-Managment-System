const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

// MySQL database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Replace with your MySQL username
  password: 'ali311', // Replace with your MySQL password
  database: 'gym_management'
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL database:', err);
    process.exit(1);
  }
  console.log('Connected to MySQL database');
});

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// API Routes

// Members API
app.get('/api/members', (req, res) => {
  db.query('SELECT * FROM members ORDER BY join_date DESC', (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

app.post('/api/members', (req, res) => {
  const { first_name, last_name, email, phone, address, date_of_birth, gender, join_date, membership_type } = req.body;
  
  db.query(
    'INSERT INTO members (first_name, last_name, email, phone, address, date_of_birth, gender, join_date, membership_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [first_name, last_name, email, phone, address, date_of_birth, gender, join_date, membership_type],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      res.status(201).json({ message: 'Member added successfully', member_id: result.insertId });
    }
  );
});

app.get('/api/members/:id', (req, res) => {
  const memberId = req.params.id;
  
  db.query('SELECT * FROM members WHERE member_id = ?', [memberId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Member not found' });
    }
    res.json(results[0]);
  });
});

// Trainers API
app.get('/api/trainers', (req, res) => {
  db.query('SELECT * FROM trainers ORDER BY hire_date DESC', (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

// Add Trainer
app.post('/api/trainers', (req, res) => {
  const { first_name, last_name, email, phone, specialization, certification, hire_date, status, profile_image } = req.body;
  if (!first_name || !last_name || !email || !hire_date) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  db.query(
    'INSERT INTO trainers (first_name, last_name, email, phone, specialization, certification, hire_date, status, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [first_name, last_name, email, phone, specialization, certification, hire_date, status || 'Active', profile_image],
    (err, result) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(409).json({ error: 'Email already exists', details: err });
        }
        return res.status(500).json({ error: 'Database error', details: err });
      }
      res.status(201).json({ message: 'Trainer added successfully', trainer_id: result.insertId });
    }
  );
});

// Get Trainer by ID
app.get('/api/trainers/:id', (req, res) => {
  const trainerId = req.params.id;
  db.query('SELECT * FROM trainers WHERE trainer_id = ?', [trainerId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Trainer not found' });
    }
    res.json(results[0]);
  });
});

// Update Trainer
app.put('/api/trainers/:id', (req, res) => {
  const trainerId = req.params.id;
  const { first_name, last_name, email, phone, specialization, certification, hire_date, status, profile_image } = req.body;
  let updateFields = [];
  let values = [];
  if (first_name) { updateFields.push('first_name = ?'); values.push(first_name); }
  if (last_name) { updateFields.push('last_name = ?'); values.push(last_name); }
  if (email) { updateFields.push('email = ?'); values.push(email); }
  if (phone) { updateFields.push('phone = ?'); values.push(phone); }
  if (specialization) { updateFields.push('specialization = ?'); values.push(specialization); }
  if (certification) { updateFields.push('certification = ?'); values.push(certification); }
  if (hire_date) { updateFields.push('hire_date = ?'); values.push(hire_date); }
  if (status) { updateFields.push('status = ?'); values.push(status); }
  if (profile_image) { updateFields.push('profile_image = ?'); values.push(profile_image); }
  if (updateFields.length === 0) {
    return res.status(400).json({ error: 'No fields to update' });
  }
  values.push(trainerId);
  db.query(
    `UPDATE trainers SET ${updateFields.join(', ')} WHERE trainer_id = ?`,
    values,
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Trainer not found' });
      }
      res.json({ message: 'Trainer updated successfully' });
    }
  );
});

// Delete Trainer
app.delete('/api/trainers/:id', (req, res) => {
  const trainerId = req.params.id;
  db.query('DELETE FROM trainers WHERE trainer_id = ?', [trainerId], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Database error', details: err });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Trainer not found' });
    }
    res.json({ message: 'Trainer deleted successfully' });
  });
});

// Membership Plans API
app.get('/api/membership-plans', (req, res) => {
  db.query('SELECT * FROM membership_plans', (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

// Workout Sessions API
app.get('/api/workout-sessions', (req, res) => {
  const query = `
    SELECT ws.*, m.first_name AS member_first_name, m.last_name AS member_last_name, 
           t.first_name AS trainer_first_name, t.last_name AS trainer_last_name
    FROM workout_sessions ws
    LEFT JOIN members m ON ws.member_id = m.member_id
    LEFT JOIN trainers t ON ws.trainer_id = t.trainer_id
    ORDER BY ws.session_date DESC, ws.start_time DESC
  `;
  
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

app.post('/api/workout-sessions', (req, res) => {
  const { member_id, trainer_id, session_date, start_time, end_time, workout_type, notes } = req.body;
  
  db.query(
    'INSERT INTO workout_sessions (member_id, trainer_id, session_date, start_time, end_time, workout_type, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [member_id, trainer_id, session_date, start_time, end_time, workout_type, notes],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      res.status(201).json({ message: 'Workout session scheduled successfully', session_id: result.insertId });
    }
  );
});

// Equipment API
app.get('/api/equipment', (req, res) => {
  db.query('SELECT * FROM equipment ORDER BY name', (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

// Add Equipment
app.post('/api/equipment', (req, res) => {
  const { name, description, purchase_date, last_maintenance, status, condition_notes } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Missing required field: name' });
  }
  db.query(
    'INSERT INTO equipment (name, description, purchase_date, last_maintenance, status, condition_notes) VALUES (?, ?, ?, ?, ?, ?)',
    [name, description, purchase_date, last_maintenance, status || 'Available', condition_notes],
    (err, result) => {
      if (err) {
        console.error('Equipment insert error:', err);
        return res.status(500).json({ error: 'Database error', details: err });
      }
      res.status(201).json({ message: 'Equipment added successfully', equipment_id: result.insertId });
    }
  );
});

// Get Equipment by ID
app.get('/api/equipment/:id', (req, res) => {
  const equipmentId = req.params.id;
  db.query('SELECT * FROM equipment WHERE equipment_id = ?', [equipmentId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Equipment not found' });
    }
    res.json(results[0]);
  });
});

// Update Equipment
app.put('/api/equipment/:id', (req, res) => {
  const equipmentId = req.params.id;
  const { name, description, purchase_date, last_maintenance, status, condition_notes } = req.body;
  let updateFields = [];
  let values = [];
  if (name) { updateFields.push('name = ?'); values.push(name); }
  if (description) { updateFields.push('description = ?'); values.push(description); }
  if (purchase_date) { updateFields.push('purchase_date = ?'); values.push(purchase_date); }
  if (last_maintenance) { updateFields.push('last_maintenance = ?'); values.push(last_maintenance); }
  if (status) { updateFields.push('status = ?'); values.push(status); }
  if (condition_notes) { updateFields.push('condition_notes = ?'); values.push(condition_notes); }
  if (updateFields.length === 0) {
    return res.status(400).json({ error: 'No fields to update' });
  }
  values.push(equipmentId);
  db.query(
    `UPDATE equipment SET ${updateFields.join(', ')} WHERE equipment_id = ?`,
    values,
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Equipment not found' });
      }
      res.json({ message: 'Equipment updated successfully' });
    }
  );
});

// Delete Equipment
app.delete('/api/equipment/:id', (req, res) => {
  const equipmentId = req.params.id;
  db.query('DELETE FROM equipment WHERE equipment_id = ?', [equipmentId], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Database error', details: err });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Equipment not found' });
    }
    res.json({ message: 'Equipment deleted successfully' });
  });
});

// Attendance API
app.post('/api/attendance/check-in', (req, res) => {
  const { member_id } = req.body;
  
  db.query(
    'INSERT INTO attendance (member_id, check_in) VALUES (?, NOW())',
    [member_id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      res.status(201).json({ message: 'Check-in recorded successfully', attendance_id: result.insertId });
    }
  );
});

app.post('/api/attendance/check-out', (req, res) => {
  const { member_id } = req.body;
  
  // First, find the latest check-in without check-out
  db.query(
    'SELECT attendance_id FROM attendance WHERE member_id = ? AND check_out IS NULL ORDER BY check_in DESC LIMIT 1',
    [member_id],
    (err, results) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      if (results.length === 0) {
        return res.status(400).json({ error: 'No active check-in found for this member' });
      }
      
      const attendance_id = results[0].attendance_id;
      
      // Update with check-out time and calculate duration
      db.query(
        `UPDATE attendance 
         SET check_out = NOW(), 
             duration_minutes = TIMESTAMPDIFF(MINUTE, check_in, NOW()) 
         WHERE attendance_id = ?`,
        [attendance_id],
        (err, result) => {
          if (err) {
            return res.status(500).json({ error: 'Database error', details: err });
          }
          res.json({ message: 'Check-out recorded successfully' });
        }
      );
    }
  );
});

// Register (Create Member with password hashing)
app.post('/api/register', async (req, res) => {
  const { first_name, last_name, email, password, phone, address, date_of_birth, gender, join_date, membership_type } = req.body;
  if (!first_name || !last_name || !email || !password || !join_date) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    db.query(
      'INSERT INTO members (first_name, last_name, email, password, phone, address, date_of_birth, gender, join_date, membership_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [first_name, last_name, email, hashedPassword, phone, address, date_of_birth, gender, join_date, membership_type],
      (err, result) => {
        if (err) {
          if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ error: 'Email already exists' });
          }
          return res.status(500).json({ error: 'Database error', details: err });
        }
        res.status(201).json({ message: 'Member registered successfully', member_id: result.insertId });
      }
    );
  } catch (err) {
    res.status(500).json({ error: 'Server error', details: err });
  }
});

// Sign-in endpoint
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Missing email or password' });
  }
  db.query('SELECT * FROM members WHERE email = ?', [email], async (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error', details: err });
    }
    if (results.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const member = results[0];
    const match = await bcrypt.compare(password, member.password);
    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    // Optionally, exclude password from response
    const { password: _, ...memberData } = member;
    res.json({ message: 'Login successful', member: memberData });
  });
});

// Update Member
app.put('/api/members/:id', async (req, res) => {
  const memberId = req.params.id;
  const { first_name, last_name, email, password, phone, address, date_of_birth, gender, join_date, membership_type, status } = req.body;
  let updateFields = [];
  let values = [];
  if (first_name) { updateFields.push('first_name = ?'); values.push(first_name); }
  if (last_name) { updateFields.push('last_name = ?'); values.push(last_name); }
  if (email) { updateFields.push('email = ?'); values.push(email); }
  if (password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    updateFields.push('password = ?'); values.push(hashedPassword);
  }
  if (phone) { updateFields.push('phone = ?'); values.push(phone); }
  if (address) { updateFields.push('address = ?'); values.push(address); }
  if (date_of_birth) { updateFields.push('date_of_birth = ?'); values.push(date_of_birth); }
  if (gender) { updateFields.push('gender = ?'); values.push(gender); }
  if (join_date) { updateFields.push('join_date = ?'); values.push(join_date); }
  if (membership_type) { updateFields.push('membership_type = ?'); values.push(membership_type); }
  if (status) { updateFields.push('status = ?'); values.push(status); }
  if (updateFields.length === 0) {
    return res.status(400).json({ error: 'No fields to update' });
  }
  values.push(memberId);
  db.query(
    `UPDATE members SET ${updateFields.join(', ')} WHERE member_id = ?`,
    values,
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Database error', details: err });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Member not found' });
      }
      res.json({ message: 'Member updated successfully' });
    }
  );
});

// Delete Member
app.delete('/api/members/:id', (req, res) => {
  const memberId = req.params.id;
  db.query('DELETE FROM members WHERE member_id = ?', [memberId], (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Database error', details: err });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Member not found' });
    }
    res.json({ message: 'Member deleted successfully' });
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});