# FitZone Gym - Fitness Tracking Application

A modern web application for gym members to track their workouts and fitness progress. Built with Node.js, Express, SQLite, and vanilla JavaScript.

## Features

- **User Registration & Authentication**: Secure user registration and login system with password hashing
- **Workout Tracking**: Add and track your workouts with exercise details
- **Progress Dashboard**: View your workout statistics and recent activities
- **Responsive Design**: Modern, mobile-friendly interface
- **Real-time Updates**: Instant feedback and data updates

## Tech Stack

- **Backend**: Node.js, Express.js
- **Database**: SQLite3
- **Authentication**: bcryptjs for password hashing
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Styling**: Custom CSS with modern design

## Installation

1. **Clone or download the project files**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the server**
   ```bash
   npm start
   ```
   
   Or for development with auto-restart:
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:3001`

## Database Setup

The application automatically creates the necessary database tables when it starts:

- **users**: Stores user account information
- **workouts**: Stores workout tracking data

The SQLite database file (`gym.db`) will be created automatically in the project root.

## Usage

### Registration
1. Click "Register" in the navigation
2. Fill in your details (name, email, password)
3. Submit the form to create your account

### Login
1. Click "Login" in the navigation
2. Enter your email and password
3. You'll be redirected to your dashboard upon successful login

### Dashboard
- **Add Workouts**: Use the form to log your exercises
- **View Progress**: See your workout statistics and recent activities
- **Track Progress**: Monitor your fitness journey over time

### Workout Tracking
- Enter exercise name, sets, reps, and weight
- All workouts are automatically timestamped
- View your workout history in the dashboard

## API Endpoints

### Authentication
- `POST /api/register` - User registration
- `POST /api/login` - User login

### Workouts
- `POST /api/workouts` - Add new workout
- `GET /api/workouts/:userId` - Get user's workouts

## Project Structure

```
gym-homepage/
├── server.js          # Main server file
├── package.json       # Dependencies and scripts
├── gym.db            # SQLite database (auto-created)
├── index.html        # Homepage
├── register.html     # Registration page
├── login.html        # Login page
├── dashboard.html    # User dashboard
├── css/
│   └── style.css     # Main stylesheet
└── README.md         # This file
```

## Security Features

- Password hashing using bcryptjs
- Input validation and sanitization
- SQL injection prevention with parameterized queries
- CORS enabled for cross-origin requests

## Development

To run the application in development mode with auto-restart:

```bash
npm run dev
```

This requires `nodemon` to be installed globally or as a dev dependency.

## Troubleshooting

### Common Issues

1. **Port already in use**: Change the port in `server.js` or kill the process using the port
2. **Database errors**: Delete `gym.db` and restart the server to recreate the database
3. **Module not found**: Run `npm install` to install dependencies

### Database Reset

To reset the database:
1. Stop the server
2. Delete `gym.db` file
3. Restart the server

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For issues or questions, please create an issue in the repository or contact the development team. 